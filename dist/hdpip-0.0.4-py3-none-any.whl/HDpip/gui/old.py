"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本文件是GUI基础轮子，~~屎山2号💩~~。
"""

from typing import *
import darkdetect
import tkinter as tk
from tkinter import scrolledtext
import maliang
from maliang import theme

try:
    from .. import core
except ImportError:
    import sys
    import pathlib
    base_dir = pathlib.Path(__file__).parents[1].resolve()
    sys.path.append(str(base_dir))
    import core

try:
    from . import base
except ImportError:
    import base

class LicenseCanvas(maliang.Canvas):
    """
    LICENSE展示画布，显示MPL-2.0许可证内容。
    纯粹的Canvas组件，可以嵌入到任何窗口中。
    """

    def __init__(self, master, width=1200, height=700):
        theme.register_event(self.licenseCanvasThemeSwitch)
        """
        初始化许可证画布。

        :param master: 父容器（可以是窗口或其他容器）
        :param width: 画布宽度，默认1200
        :param height: 画布高度，默认700
        """
        super().__init__(master, expand="xy", auto_zoom=True, auto_update=True)
        self.width = width
        self.height = height

        # 创建ScrolledText到Canvas中
        self.license_text = scrolledtext.ScrolledText(
            self,
            wrap=tk.WORD,
            font=("Consolas", 14),
            bg="#f8f9fa",
            fg="#212529",
            relief=tk.FLAT,
            borderwidth=2
        )

        # 将ScrolledText放置到Canvas中
        self.create_window(0, 0, window=self.license_text,
                          width=self.width, height=self.height, anchor="nw")

        # 配置文本居中
        self.license_text.tag_configure("center", justify='center')

        # 加载LICENSE文件内容
        try:
            license_path = core.base.getBaseDir().parent / "LICENSE"
            with open(license_path, 'r', encoding='utf-8') as f:
                license_content = f.read()

            self.license_text.delete(1.0, tk.END)
            self.license_text.insert(1.0, license_content)
            # 应用居中标签
            self.license_text.tag_add("center", "1.0", "end")
            self.license_text.config(state=tk.DISABLED)

        except Exception as e:
            self.license_text.delete(1.0, tk.END)
            self.license_text.insert(1.0, f"无法加载许可证文件:\n{str(e)}")
            # 错误信息也居中
            self.license_text.tag_add("center", "1.0", "end")

    def licenseCanvasThemeSwitch(self, theme: Literal["system", "light", "dark"] = "system") -> None:
        match theme:
            case "light":
                self.license_text.configure(bg = "white", fg = "black")
            case "dark":
                self.license_text.configure(bg = "black", fg = "white")
            case "system":
                self.licenseCanvasThemeSwitch("dark" if darkdetect.isDark() else "light")



# 示例使用方式
if __name__ == "__main__":
    # 创建一个测试窗口来演示如何使用LicenseCanvas
    root = maliang.Tk((1200, 700), title="测试 - LicenseCanvas")

    # 创建LicenseCanvas实例（作为Canvas组件）
    license_canvas = LicenseCanvas(root)
    license_canvas.place(width=1200, height=700, x=0, y=0)
    license_canvas.after(2000, lambda: theme.set_color_mode("dark"))

    root.mainloop()

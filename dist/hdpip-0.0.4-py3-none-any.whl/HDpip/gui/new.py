from typing import *

import tkinter.ttk
import maliang
import maliang.theme
import maliang.core.configs

class TreeView(tkinter.ttk.Treeview):
    def __init__(self, master, **kwargs: Any):
        super().__init__(master, **kwargs)

maliang.core.configs.Env.system = "Windows11"
root = maliang.Tk((400, 400))
root.center()
canvas = maliang.Canvas(root)
canvas.place(x = 0, y = 0, width = 400, height = 400)
canvas.after(1000, lambda: maliang.theme.set_color_mode("dark"))
root.mainloop()
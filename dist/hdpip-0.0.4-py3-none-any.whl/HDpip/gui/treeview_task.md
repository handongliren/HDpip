# TreeView控件重构

## 功能要求

1. 要求实现列宽更改可动态更新禁用状态，手动拖拽时滚动条同步宽度显示，保持滚动条可操作。
2. 支持亮暗模式切换，亮色模式下，前景dark背景light选中前景dark选中背景info，暗色模式下，前景light背景dark选中前景light选中背景primary，对应颜色在`/HDpip/gui/base.py`中。
3. 可动态更改列标题列宽，show参数支持选择，支持动态更改tree和headings。

## 开发细则

1. 输出到`/HDpip/gui/treeview.py`。
2. 使用maliang.Canvas作为容器
